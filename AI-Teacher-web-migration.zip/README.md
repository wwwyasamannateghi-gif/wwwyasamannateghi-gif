# AI Teacher — FastAPI + HTML/CSS/JS

نسخه Web App پروژه AI Teacher، بدون Streamlit.

## ساختار

- `backend/main.py` — API و اتصال امن به OpenRouter
- `backend/requirements.txt` — وابستگی‌های Backend
- `frontend/` — رابط کاربری Responsive و آماده PWA
- `.env.example` — نمونه متغیرهای محیطی
- `render.yaml` — تنظیم اولیه Deploy روی Render
- `vercel.json` — تنظیم اولیه Frontend روی Vercel

## اجرای محلی

1. در `backend` محیط مجازی بسازید و وابستگی‌ها را نصب کنید.
2. فایل `.env` را در ریشه پروژه بسازید و `OPENROUTER_API_KEY` را قرار دهید.
3. Backend:
   `uvicorn main:app --reload --port 8000`
4. Frontend را با یک static server اجرا کنید، نه با `file://`.
   مثال:
   `python -m http.server 5500 --directory frontend`
5. اگر Frontend روی پورت 5500 است، متغیر `FRONTEND_ORIGIN=http://localhost:5500` باشد.
6. برای اتصال Frontend به Backend روی دامنه دیگر، مقدار `AI_TEACHER_API` را در ابتدای `frontend/script.js` یا در محیط Deploy تنظیم کنید.

## امنیت

کلید OpenRouter فقط در Backend و Environment Variable نگهداری می‌شود و نباید داخل Frontend یا GitHub قرار گیرد.

## Quiz

آزمون دقیقاً ۵ سؤال دارد. سؤال‌ها یک‌بار تولید و در `sessionStorage` مرورگر نگهداری می‌شوند؛ جابه‌جایی سؤال‌ها درخواست جدید به AI نمی‌فرستد. Backend قبل از ارسال آزمون، JSON، تعداد سؤال‌ها، تعداد گزینه‌ها، یکتا بودن گزینه‌ها و معتبر بودن index پاسخ صحیح را بررسی می‌کند و در صورت خطا تا ۳ بار تولید را تکرار می‌کند.

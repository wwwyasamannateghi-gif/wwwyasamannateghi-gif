const API_BASE = (window.AI_TEACHER_API || "").replace(/\/$/, "");

const modeData = {
  question: {
    title: "💬 سؤال بپرس",
    help: "سؤال خودت را درباره کامپیوتر و موضوعات مرتبط بپرس.",
    placeholder: "سؤال خود را بنویسید..."
  },
  explain: {
    title: "📚 توضیح بده",
    help: "یک موضوع را وارد کن تا AI Teacher آن را مثل یک معلم توضیح دهد.",
    placeholder: "موضوع یا مفهومی که می‌خواهید یاد بگیرید..."
  },
  hint: {
    title: "💡 راهنمایی کن",
    help: "مسئله را بگو تا با Hint و سؤال‌های راهنما به جواب برسی.",
    placeholder: "مسئله یا تمرینی که در آن گیر کرده‌اید..."
  }
};

let currentMode = "question";
let quizState = {
  questions: [],
  index: 0,
  score: 0,
  answered: false,
  selected: null,
  topic: ""
};

const $ = (id) => document.getElementById(id);

function setStatus(el, message, error = false) {
  el.hidden = !message;
  el.textContent = message || "";
  el.classList.toggle("error", error);
}

function apiUrl(path) {
  return `${API_BASE}${path}`;
}

function renderSimpleMarkdown(text) {
  // Safe lightweight renderer: escape HTML first, then support the markdown
  // constructs AI Teacher needs most: fenced code, inline code, headings, lists.
  const escaped = String(text)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");

  const blocks = [];
  const withPlaceholders = escaped.replace(/```([\w+-]*)\n?([\s\S]*?)```/g, (_, lang, code) => {
    const id = `@@CODE${blocks.length}@@`;
    blocks.push(`<pre><code>${code.trim()}</code></pre>`);
    return id;
  });

  let html = withPlaceholders
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/^### (.*)$/gm, "<h4>$1</h4>")
    .replace(/^## (.*)$/gm, "<h3>$1</h3>")
    .replace(/^# (.*)$/gm, "<h2>$1</h2>")
    .replace(/^\s*[-*] (.*)$/gm, "<li>$1</li>")
    .replace(/\n{2,}/g, "</p><p>")
    .replace(/\n/g, "<br>");

  html = html.replace(/(<li>.*?<\/li>)(?:<br>)?/g, "$1");
  blocks.forEach((block, i) => { html = html.replace(`@@CODE${i}@@`, block); });
  return `<p>${html}</p>`;
}

async function postJson(path, body) {
  const response = await fetch(apiUrl(path), {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(body)
  });
  let data = {};
  try { data = await response.json(); } catch (_) {}
  if (!response.ok) {
    throw new Error(data.detail || "خطایی در ارتباط با سرور رخ داد.");
  }
  return data;
}

function setMode(mode) {
  currentMode = mode;
  document.querySelectorAll(".mode-btn").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.mode === mode);
  });

  const isQuiz = mode === "quiz";
  $("learningCard").hidden = isQuiz;
  $("quizCard").hidden = !isQuiz;

  if (!isQuiz) {
    $("learningTitle").textContent = modeData[mode].title;
    $("learningHelp").textContent = modeData[mode].help;
    $("questionInput").placeholder = modeData[mode].placeholder;
  }
}

async function sendQuestion() {
  const question = $("questionInput").value.trim();
  if (!question) {
    setStatus($("chatStatus"), "لطفاً ابتدا سؤال خود را بنویسید.", true);
    return;
  }

  $("sendBtn").disabled = true;
  $("sendBtn").textContent = "🤖 در حال فکر کردن...";
  setStatus($("chatStatus"), "AI Teacher در حال پاسخ دادن است...");
  $("answerBox").hidden = true;

  try {
    const data = await postJson("/api/chat", {mode: currentMode, question});
    $("answerContent").innerHTML = renderSimpleMarkdown(data.answer);
    $("answerBox").hidden = false;
    setStatus($("chatStatus"), "");
  } catch (err) {
    setStatus($("chatStatus"), err.message, true);
  } finally {
    $("sendBtn").disabled = false;
    $("sendBtn").textContent = "🚀 ارسال سؤال";
  }
}

async function startQuiz() {
  const topic = $("quizTopic").value.trim();
  if (!topic) {
    setStatus($("quizStatus"), "لطفاً ابتدا موضوع آزمون را بنویسید.", true);
    return;
  }

  $("startQuizBtn").disabled = true;
  $("startQuizBtn").textContent = "🤖 در حال ساخت آزمون...";
  setStatus($("quizStatus"), "سؤال‌ها فقط یک‌بار تولید می‌شوند؛ لطفاً چند لحظه صبر کنید.");
  $("quizArea").hidden = true;
  $("quizResult").hidden = true;

  try {
    const data = await postJson("/api/quiz", {topic});
    if (!Array.isArray(data.questions) || data.questions.length !== 5) {
      throw new Error("آزمون معتبر دریافت نشد.");
    }

    // Session-level persistence: changing questions never calls the AI again.
    quizState = {
      questions: data.questions,
      index: 0,
      score: 0,
      answered: false,
      selected: null,
      topic
    };
    sessionStorage.setItem("aiTeacherQuiz", JSON.stringify(quizState));
    setStatus($("quizStatus"), "");
    renderQuizQuestion();
  } catch (err) {
    setStatus($("quizStatus"), err.message, true);
  } finally {
    $("startQuizBtn").disabled = false;
    $("startQuizBtn").textContent = "🚀 شروع آزمون";
  }
}

function saveQuiz() {
  sessionStorage.setItem("aiTeacherQuiz", JSON.stringify(quizState));
}

function loadQuiz() {
  try {
    const saved = JSON.parse(sessionStorage.getItem("aiTeacherQuiz") || "null");
    if (saved && Array.isArray(saved.questions) && saved.questions.length === 5) {
      quizState = saved;
      renderQuizQuestion();
    }
  } catch (_) {
    sessionStorage.removeItem("aiTeacherQuiz");
  }
}

function renderQuizQuestion() {
  const q = quizState.questions[quizState.index];
  if (!q) return;

  $("quizArea").hidden = false;
  $("quizResult").hidden = true;
  $("quizCounter").textContent = `📝 سؤال ${quizState.index + 1} از 5`;
  $("quizPercent").textContent = `${Math.round(((quizState.index + 1) / 5) * 100)}%`;
  $("progressBar").style.width = `${((quizState.index + 1) / 5) * 100}%`;
  $("quizQuestion").textContent = q.question;

  const options = $("options");
  options.innerHTML = "";
  quizState.selected = null;
  quizState.answered = false;

  q.options.forEach((option, i) => {
    const btn = document.createElement("button");
    btn.className = "option";
    btn.type = "button";
    btn.textContent = `${i + 1}. ${option}`;
    btn.addEventListener("click", () => {
      if (quizState.answered) return;
      quizState.selected = i;
      document.querySelectorAll(".option").forEach(x => x.classList.remove("selected"));
      btn.classList.add("selected");
      $("submitAnswerBtn").disabled = false;
    });
    options.appendChild(btn);
  });

  $("submitAnswerBtn").hidden = false;
  $("submitAnswerBtn").disabled = true;
  $("feedback").hidden = true;
  $("nextQuestionBtn").hidden = true;
  $("finishQuizBtn").hidden = true;
  saveQuiz();
}

function submitAnswer() {
  if (quizState.selected === null) return;
  const q = quizState.questions[quizState.index];
  quizState.answered = true;

  const correct = quizState.selected === q.answer;
  if (correct) quizState.score++;

  document.querySelectorAll(".option").forEach((btn, i) => {
    btn.disabled = true;
    if (i === q.answer) btn.classList.add("selected");
  });

  const feedback = $("feedback");
  feedback.hidden = false;
  feedback.className = `feedback ${correct ? "success" : "error"}`;
  feedback.innerHTML = correct
    ? `🎉 پاسخ شما صحیح است!<br><strong>📚 توضیح آموزشی:</strong> ${escapeHtml(q.explanation)}`
    : `❌ پاسخ شما اشتباه است.<br><strong>پاسخ صحیح:</strong> ${escapeHtml(q.options[q.answer])}<br><strong>📚 توضیح آموزشی:</strong> ${escapeHtml(q.explanation)}`;

  $("submitAnswerBtn").hidden = true;
  if (quizState.index < 4) $("nextQuestionBtn").hidden = false;
  else $("finishQuizBtn").hidden = false;
  saveQuiz();
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;").replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;").replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function nextQuestion() {
  if (!quizState.answered) return;
  quizState.index++;
  renderQuizQuestion();
}

function finishQuiz() {
  if (!quizState.answered) return;
  const score = quizState.score;
  const wrong = 5 - score;
  const percentage = score * 20;
  let message = percentage >= 80
    ? "🌟 عالی بود! تسلط خیلی خوبی روی این مبحث داری."
    : percentage >= 50
      ? "👍 خوب بود! با کمی تمرین بیشتر بهتر هم می‌شوی."
      : "📚 بهتر است این مبحث را دوباره مرور کنی و دوباره امتحان بدهی.";

  $("quizArea").hidden = true;
  $("quizResult").hidden = false;
  $("quizResult").innerHTML = `
    <div>🎉 آزمون تمام شد!</div>
    <div class="result-percent">${percentage}%</div>
    <div>${escapeHtml(message)}</div>
    <div class="result-grid">
      <div class="result-stat">✅ پاسخ صحیح: ${score}</div>
      <div class="result-stat">❌ پاسخ غلط: ${wrong}</div>
    </div>
    <button id="newQuizBtn" class="primary-btn" style="margin-top:14px">🔄 آزمون جدید</button>
  `;
  $("newQuizBtn").addEventListener("click", () => {
    sessionStorage.removeItem("aiTeacherQuiz");
    quizState = {questions: [], index: 0, score: 0, answered: false, selected: null, topic: ""};
    $("quizResult").hidden = true;
    $("quizTopic").value = "";
    setStatus($("quizStatus"), "");
  });
}

document.querySelectorAll(".mode-btn").forEach(btn => {
  btn.addEventListener("click", () => setMode(btn.dataset.mode));
});
$("sendBtn").addEventListener("click", sendQuestion);
$("startQuizBtn").addEventListener("click", startQuiz);
$("submitAnswerBtn").addEventListener("click", submitAnswer);
$("nextQuestionBtn").addEventListener("click", nextQuestion);
$("finishQuizBtn").addEventListener("click", finishQuiz);
$("questionInput").addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") sendQuestion();
});

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("./sw.js").catch(() => {});
}
loadQuiz();
